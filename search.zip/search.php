<?php
/**
 * 高级flag搜索器
 */

class AdvancedFlagHunter {
    private $results = [];
    private $options = [
        'max_depth' => 10,
        'max_file_size' => 5242880, // 5MB
        'extensions' => ['txt', 'php', 'html', 'js', 'json', 'xml', 'md'],
        'skip_dirs' => ['.git', 'node_modules', 'vendor', '__pycache__'],
    ];
    
    public function __construct($options = []) {
        $this->options = array_merge($this->options, $options);
    }
    
    public function hunt($dir = '.') {
        $this->walk($dir, 0);
        return $this->results;
    }
    
    private function walk($dir, $depth) {
        if ($depth > $this->options['max_depth']) {
            return;
        }
        
        try {
            $iterator = new RecursiveIteratorIterator(
                new RecursiveDirectoryIterator($dir, RecursiveDirectoryIterator::SKIP_DOTS),
                RecursiveIteratorIterator::SELF_FIRST
            );
            
            foreach ($iterator as $file) {
                $path = $file->getPathname();
                
                // 跳过指定目录
                foreach ($this->options['skip_dirs'] as $skipDir) {
                    if (strpos($path, DIRECTORY_SEPARATOR . $skipDir) !== false) {
                        continue 2;
                    }
                }
                
                // 检查文件扩展名
                if ($file->isFile()) {
                    $ext = $file->getExtension();
                    if (!empty($this->options['extensions']) && 
                        !in_array(strtolower($ext), $this->options['extensions'])) {
                        continue;
                    }
                    
                    $this->checkFile($file);
                }
                
                // 检查目录名
                if ($file->isDir()) {
                    $this->checkDir($file);
                }
            }
        } catch (Exception $e) {
            error_log("搜索错误: " . $e->getMessage());
        }
    }
    
    private function checkFile($file) {
        $path = $file->getPathname();
        $size = $file->getSize();
        
        if ($size > $this->options['max_file_size']) {
            return;
        }
        
        // 检查文件名
        $this->checkFileName($file->getFilename(), $path);
        
        // 检查文件内容
        if (is_readable($path)) {
            $content = @file_get_contents($path);
            if ($content !== false) {
                $this->checkContent($content, $path);
            }
        }
    }
    
    private function checkFileName($filename, $path) {
        $patterns = [
            '/flag/i',
            '/ctf/i',
            '/secret/i',
            '/password/i',
            '/key/i',
            '/token/i',
            '/\.env$/',
            '/config$/i',
        ];
        
        foreach ($patterns as $pattern) {
            if (preg_match($pattern, $filename)) {
                $this->addResult('可疑文件名', $path, $filename);
            }
        }
    }
    
    private function checkContent($content, $path) {
        // 常见flag格式
        $patterns = [
            '/flag{[^}]+}/i',
            '/ctf{[^}]+}/i',
            '/[a-f0-9]{32}/i',  // MD5
            '/[a-f0-9]{40}/i',  // SHA1
            '/[a-f0-9]{64}/i',  // SHA256
            '/[a-z0-9]{8}-[a-z0-9]{4}-[a-z0-9]{4}-[a-z0-9]{4}-[a-z0-9]{12}/i', // UUID
        ];
        
        // 关键词
        $keywords = [
            'flag',
            'ctf',
            'secret',
            'password',
            'key',
            'token',
            'admin',
            'root',
            'credentials',
        ];
        
        // 检查模式
        foreach ($patterns as $pattern) {
            if (preg_match_all($pattern, $content, $matches)) {
                foreach ($matches[0] as $match) {
                    $this->addResult('模式匹配', $path, $match);
                }
            }
        }
        
        // 检查关键词
        foreach ($keywords as $keyword) {
            $lines = explode("\n", $content);
            foreach ($lines as $lineNum => $line) {
                if (stripos($line, $keyword) !== false) {
                    $line = trim($line);
                    if (strlen($line) > 100) {
                        $line = substr($line, 0, 100) . '...';
                    }
                    $this->addResult(
                        "关键词: $keyword", 
                        $path, 
                        "行 " . ($lineNum + 1) . ": " . $line
                    );
                }
            }
        }
    }
    
    private function checkDir($dir) {
        $dirname = basename($dir->getPathname());
        if (preg_match('/(flag|ctf|secret|backup)/i', $dirname)) {
            $this->addResult('可疑目录名', $dir->getPathname(), '');
        }
    }
    
    private function addResult($type, $path, $content) {
        $this->results[] = [
            'type' => $type,
            'path' => $path,
            'content' => $content,
            'time' => date('H:i:s'),
        ];
    }
    
    public function getReport() {
        $report = "高级Flag搜索报告\n";
        $report .= "生成时间: " . date('Y-m-d H:i:s') . "\n";
        $report .= "搜索深度: " . $this->options['max_depth'] . "\n";
        $report .= "最大文件: " . ($this->options['max_file_size'] / 1024 / 1024) . "MB\n";
        $report .= "=" . str_repeat("=", 60) . "\n\n";
        
        $groups = [];
        foreach ($this->results as $result) {
            $groups[$result['type']][] = $result;
        }
        
        foreach ($groups as $type => $items) {
            $report .= "[$type] 找到 " . count($items) . " 个结果:\n";
            foreach ($items as $item) {
                $report .= "  • 文件: " . $item['path'] . "\n";
                if (!empty($item['content'])) {
                    $report .= "    内容: " . $item['content'] . "\n";
                }
                $report .= "    时间: " . $item['time'] . "\n";
            }
            $report .= "\n";
        }
        
        $report .= "总计找到: " . count($this->results) . " 个可疑项目\n";
        return $report;
    }
}

// 使用示例
$hunter = new AdvancedFlagHunter([
    'max_depth' => 5,
    'max_file_size' => 2 * 1024 * 1024, // 2MB
    'extensions' => ['txt', 'php', 'html', 'js', 'json', 'md', 'yml', 'yaml', 'ini'],
]);

echo "开始高级flag搜索...\n";
$results = $hunter->hunt('.');

if (empty($results)) {
    echo "未找到flag\n";
} else {
    echo $hunter->getReport();
    
    // 保存报告
    file_put_contents('advanced_flag_report.txt', $hunter->getReport());
    echo "详细报告已保存到: advanced_flag_report.txt\n";
}
?>